<template>
	<view class="m-index">
		<view style=" height: var(--status-bar-height);">

		</view>
		<view class="black">
			<uni-nav-bar left-icon="left" title="收支日历" @clickLeft="back" />
		</view>
		<view>
			<uni-calendar :insert="true" :lunar="false" :start-date="'2023-02-1'" :end-date="'2029-12-31'"
				:selected="selected" @change="change" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				selected: [{
					date: '2023-03-27',
					info: '-100',
				}]

			}
		},
		methods: {
			back() {
				uni.navigateBack({
					delta: 2
				});
			},
			change(){}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #F4F4F4;
	}
</style>
