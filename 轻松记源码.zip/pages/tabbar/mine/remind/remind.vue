<template>
	<page-meta :root-font-size="getRootFontSize()"></page-meta>
	<view class="content">
		<uni-popup ref="popup" type="dialog">
			<uni-popup-dialog message="成功消息" :duration="2000" :before-close="true" @close="close" @confirm="confirm">确定要删除改账本吗？</uni-popup-dialog>
		</uni-popup>
		<!-- 标题 -->
		<view class="total_title">
			<view class="back">
				<image src="../../../../static/img/mine/back.png" alt="">
				<text @click="back_it()">返回</text>
			</view>
			<view class="ach_title">
				记账提醒
			</view>
			<view class="wei">
				
			</view>
		</view>
		<view class="lock">
			<view class="title">定时提醒</view>
			<view class="confirm_ut">
				<view class="big_circle"  @click="openb()" :class="{'open':this.openm==1}">
					<view class="small_circle" :class="{'open_1':this.openm==1}">
						
					</view>
				</view>
				
			</view>
		</view>
	</view>
	
</template>

<script>
	import remind from "../../../../static/json/rem.json"
	import CalendarEvent from '@/uni_modules/lgen-remind/js_sdk/index.js'
	import base from '@/static/base.js';
	export default {
		extends:base,
		data() {
			return {
				openm:0,
				 remindFn:''
			}
		},
		onLoad(){
			this.openm = remind.remind
			
			 // #ifdef APP-PLUS
			        this.remindFn=new CalendarEvent()
			
			        this.remindFn.handleRecord((res)=>{
			            console.log(res)
			        })
			        // #endif
		},
		onShow(){
			
		},
		methods: {
			openb(){
				remind.remind = (remind.remind+1)%2
					this.openm = remind.remind
				if(this.openm == 1){
					this.calendarRemind()
					let platform = uni.getSystemInfoSync().platform; //获取安卓还是ios
									this.tongzhi = false;
									if (platform == "ios") {//如果机型是ios，ios由于权限问题，可能需要手动开启
										var UIApplication = plus.ios.import("UIApplication");
										var app = UIApplication.sharedApplication();
										var settings = app.currentUserNotificationSettings();
										enabledTypes = settings.plusGetAttribute("types");
										var NSURL2 = plus.ios.import("NSURL");
										var setting2 = NSURL2.URLWithString("app-settings:");
										var application2 = UIApplication.sharedApplication();
										application2.openURL(setting2);
										plus.ios.deleteObject(setting2);
										plus.ios.deleteObject(NSURL2);
										plus.ios.deleteObject(application2);
										plus.ios.deleteObject(settings);
									} else if (platform == "android") {//如果机型是安卓
										var main = plus.android.runtimeMainActivity();
										var pkName = main.getPackageName();
										var uid = main.getApplicationInfo().plusGetAttribute("uid");
										var Intent = plus.android.importClass("android.content.Intent");
										var Build = plus.android.importClass("android.os.Build");
										//android 8.0引导
										if (Build.VERSION.SDK_INT >= 26) { //判断安卓系统版本
											var intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
											intent.putExtra("android.provider.extra.APP_PACKAGE", pkName);
										} else if (Build.VERSION.SDK_INT >= 21) { //判断安卓系统版本
											//android 5.0-7.0
											var intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
											intent.putExtra("app_package", pkName);
											intent.putExtra("app_uid", uid);
										} else {
											//(<21)其他--跳转到该应用管理的详情页
											intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
											var uri = Uri.fromParts(
												"package",
												mainActivity.getPackageName(),
												null
											);
											intent.setData(uri);
										}
										// 跳转到该应用的系统通知设置页
										main.startActivity(intent);
									}
				}
			},
			back_it(){
				uni.navigateBack(1)
			},
			calendarRemind(){
				
			            const tomorrowTime=new Date().getTime()+24*60*60*1000
			const entime=new Date().getTime()+60*10000+100000
			            this.remindFn.addRemind({
			                'name':'记账',
			                'title':'记账提醒',
			                'subtitle':'今日还未记账噢',
			                'description':'',
			                'dtstart':tomorrowTime,
							'dtend':entime,
			                'storageKey':'aTime'
			            },()=>{
			                console.log('ok')
			            })
						
				
			        }
					
			}
	}
</script>

<style>
	.open{
		background-color: forestgreen !important;
	}
		
	.open_1{
		position: absolute;
		left: 2.2rem !important;
	}
	.title{
		width: 50%;
		height: 100%;
		line-height: 3rem;
		box-sizing: border-box;
		padding-left: 2rem;
	}
	.confirm_ut{
		width:50%;
		height: 100%;
	}
		
	.big_circle{
		width: 4rem;
		height: 1.8rem;
		background-color: darkgray;
		border-radius: 2rem;
		position: absolute;
		top: 50%;
		transform: translateY(-50%);
		right: 2rem;
	}
	.small_circle{
		transition: all 0.5s;
		width: 1.6rem;
		height: 1.6rem;
		background-color: white;
		border-radius: 50%;
		position: absolute;
		top: 50%;
		left: 0.1rem;
		transform: translateY(-50%);
	}
	.lock{
		position: relative;
		height: 3rem;
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	/*  */
	.content{
		position: fixed;
		width: 100%;
		height: 1000px;
		background-color: rgb(244, 244, 244);
		font-size: 16px;
	}
	
	/* first */
.total_title{
		color:rgb(100, 100, 100);
		padding: 4rem 0.3rem 0;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.back{
		display: flex;
		align-items: center;
		color: dimgray;
		flex: 1;
	}
	.back image{
		width: 25px;
		height: 25px;
	}
	.ach_title{
		flex: 2;
		font-weight: 600;
		text-align: center;
		padding-right: 10px;
	}
	.wei{
		flex: 1;
		text-align: center;
	}
	.delete_it{
		position: absolute;
		right: 0;
	}
</style>
