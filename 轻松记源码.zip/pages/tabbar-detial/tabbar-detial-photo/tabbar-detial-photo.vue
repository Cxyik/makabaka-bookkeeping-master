<template>
	<page-meta :root-font-size="getRootFontSize()"></page-meta>
	<view class="m-index">
		<view style=" height: var(--status-bar-height);">

		</view>
		<view class="black">
			<uni-nav-bar left-icon="left" title="识别结果" @clickLeft="back" />
		</view>
		<u-loading-icon text="正在识别" textSize="18" :show="isLoad"></u-loading-icon>
		<view class="m-main"  v-show="!isLoad">
			<view class="m-res" >
				<view>
					<text>种类:</text>
					<uni-easyinput type="text" :inputBorder="false"  :value="data.category" placeholder="种类">
					</uni-easyinput>
				</view>
				<view>
					<text>金额:</text>
					<uni-easyinput type="number" :inputBorder="false" :value="data.amount" placeholder="金额">
					</uni-easyinput>
				</view>
				<view>
					<text>时间:</text>
					<text style="margin-left: 1rem">{{data.expenditureDate}}</text>
				</view>
		
				
				<view>
					<text style="margin-top: 0.5rem">备注:</text>
					<uni-easyinput type="textarea"  :value="data.comment" :autoHeight="true" placeholder="备注">
					</uni-easyinput>
				</view>

			</view>
			<view class="button">
				<u-button size="small" @click="save">确定</u-button>
			</view>
			<view class="history-res">

			</view>
		</view>
	</view>
</template>


<script>
	import base from '@/static/base.js';
	export default {
		extends:base,
		data() {
			return {
				date: '2023-02-27',
				isLoad: true,
				data:{
					amount: "59.40",
					category: "食品餐饮",
					comment: "BHG(华联超市)",
					expenditureDate: "2022-11-28",
					subcategory: "生鲜食品",
				}

			};
		},
		onReady() {
			var that=this
			uploadImg(that)
		},
		methods: {
			back() {
				uni.reLaunch({
					url: '/pages/tabbar/account_book/account_book',
				})
			},
			save(){
				var that = this
				var param=this.data
				save(that,param,"expenditure")
			}
		},
		
	};
	const save = (that, param, type) => {
		var api = that.GLOBAL.baseApi
		uni.request({
			url: api + "/" + type + "/save",
			method: "POST",
			header: {
				'content-type': 'application/json;charset:utf-8'
			},
			data: param,
			success: (res) => {
				console.log("seuuess")
				uni.reLaunch({
					url: '/pages/tabbar/account_book/account_book',
				})
			}
		})
	}
	const uploadImg=(that)=>{
		uni.chooseImage({
			count: 6, //默认9
			sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			sourceType: ['camera'], //
			success: (chooseImageRes) => {
				const tempFilePaths = chooseImageRes.tempFilePaths;
		
				const uploadTask = uni.uploadFile({
					url: 'http://43.143.3.149:4321/keepAccounts/image', //仅为示例，非真实的接口地址
					filePath: tempFilePaths[0],
					name: 'files',
					success: (uploadFileRes) => {
						const {
							code ,data
						} = JSON.parse(uploadFileRes.data)
						if (code === 200) {
							console.log(data)
							that.data=data
							that.isLoad = false
						}
					}
				});
			}
		});
	}
</script>

<style lang="scss">
	page {
		background-color: #f4f4f4
	}

	.section {
		display: flex;
		align-items: center;
		margin: 0.5rem 0 0.5rem 0;

		view:nth-child(1) {
			background-color: #E26E59;
			width: 0.3rem;
			height: 2rem;
			margin-right: 0.5rem;
			border-radius: 9rem;
		}
	}

	.m-main {
		margin: 1rem 0.5rem 0 0.5rem;
		background-color: white;
		border-radius: 0.5rem;
		display: flex;
		flex-direction: column;
		align-items: center;
		color: #666666;
	}

	.m-res {

		// padding: 0.1rem;
		width: 95%;

		view {
			// margin: 4rem 0;
			margin: 0.3rem;
			display: flex;
			align-items: center;

			text {
				margin: 0 .2rem 0 0;
			}
		}
	

	}
	
	.button {
		margin: 0.5rem;
	}
</style>
