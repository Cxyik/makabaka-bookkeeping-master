## 更新日志

#### 1.0.8（2022-07-29）
#### 1.0.8（2022-07-29）
1、修复微信小程序中w-radio-picker默认值为undefind或null时，无法选中对应空选项问题
2、修复微信小程序中w-datetime-picker点击弹出picker报错问题
3、w-radio-picker添加value和options变化监听
4、w-checkbox-picker添加value和options变化监听
5、w-datetime-picker添加value变化监听
6、w-select-ro-input添加value和options变化监听
7、w-address-picker添加value和label变化监听
## 1.0.7（2022-06-01）
删除@update自定义事件，添加v-model语法糖

##
## 1.0.6（2022-05-18）
1、修复组件右侧图标在微信小程序下样式未生效问题
2、修复w-checkbox-picker选项值显示问题
3、优化代码逻辑，提升性能

##
## 1.0.5（2022-05-17）
1、修复w-address-picker组件只有省市，没有区县数据时无法选择的问题
2、修复webview下样式不一致问题
3、修复w-select-or-input和w-address-picker在微信小程序下不显示图标问题

##
## 1.0.4（2022-05-16）
提交组件预览截图

##
## 1.0.3（2022-05-16）
修复文档格式错乱
##
## 1.0.2（2022-05-16）
1、添加w-select-ro-input输入或选择组件
2、添加w-address-picker省市区三级联动选择组件
3、完善nvue下css样式
##
## 1.0.1（2022-05-16）
1、修复w-checkbox-picker选项值显示问题
2、完善组件文档
3、添加w-datetime-picker日期时间选择组件
#### 1.0.0（2022-05-13）
1、首次提交代码，持续更新迭代